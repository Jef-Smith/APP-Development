import React, { useState } from 'react';
import axios from 'axios';
import './Chatbot.css';

const Chatbot = () => {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState([]);

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:8080/chat', { message: input });
      setResponse(res.data.response);
    } catch (error) {
      console.error("There was an error posting the data!", error);
    }
  };

  return (
    <div className="chatbot">
      <h2>Fitness Exercise Advisor</h2>
      <form onSubmit={handleSubmit}>
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder="Enter your fitness question or goal"
          rows="4"
          cols="50"
        />
        <button type="submit">Get Fitness Advice</button>
      </form>
      {response.length > 0 && (
        <div className="response">
          <h3>Generated Fitness Advice:</h3>
          <ul>
            {response.map((advice, index) => (
              <li key={index}>{advice}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
