import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Home from './components/Home';
import Signup from './components/Signup';
import Workouts from './components/Workouts';
import Nutrition from './components/Nutrition';
import AiCoach from './components/AiCoach';
import ChallengeDetails from './components/ChallengeDetails';
import JoinChallenge from './components/JoinChallenge';
import ProtectedRoute from './components/ProtectedRoute';
import Chatbot from './components/Chatbot';
import Login from './components/Login';
import Footer from './components/Footer';

import running from './components/runningImage.png';
import yoga from './components/yogaImage.png';
import Strength from './components/weightliftingImage.png';
import Cycling from './components/cyclingImage.jpg';
import Swimming from './components/swimmingImage.jpg';

const initialChallengeData = {
  'weekly-running-challenge': {
    title: 'Weekly Running Challenge',
    description: 'Increase your running distance by 10% each week.',
    startDate: '2024-07-01',
    endDate: '2024-07-07',
    image: running,
    participants: [
      { name: 'Alice', status: 'Completed 5/10 runs', progress: 50 },
      { name: 'Bob', status: 'In Progress', progress: 30 },
      { name: 'Charlie', status: 'Completed 3/10 runs', progress: 30 },
      { name: 'David', status: 'Not Started', progress: 0 },
      { name: 'Eve', status: 'Completed 8/10 runs', progress: 80 },
      { name: 'Frank', status: 'In Progress', progress: 20 },
    ],
  },
  'monthly-yoga-challenge': {
    title: 'Monthly Yoga Challenge',
    description: 'Master a new yoga pose every week.',
    startDate: '2024-07-01',
    endDate: '2024-07-31',
    image: yoga,
    participants: [
      { name: 'Ella', status: 'Completed 3/4 poses', progress: 75 },
      { name: 'Frank', status: 'In Progress', progress: 50 },
      { name: 'Grace', status: 'Completed 2/4 poses', progress: 50 },
      { name: 'Hannah', status: 'Not Started', progress: 0 },
      { name: 'Isla', status: 'Completed 4/4 poses', progress: 100 },
      { name: 'Jack', status: 'In Progress', progress: 25 },
    ],
  },
  'strength-challenge': {
    title: 'Strength Challenge',
    description: 'Increase your weightlifting load by 5% each week.',
    startDate: '2024-07-01',
    endDate: '2024-07-31',
    image: Strength,
    participants: [
      { name: 'Isaac', status: 'Completed 4/5 weeks', progress: 80 },
      { name: 'Jasmine', status: 'In Progress', progress: 60 },
      { name: 'Kieran', status: 'Completed 2/5 weeks', progress: 40 },
      { name: 'Liam', status: 'Not Started', progress: 0 },
      { name: 'Mia', status: 'Completed 5/5 weeks', progress: 100 },
      { name: 'Noah', status: 'In Progress', progress: 50 },
    ],
  },
  'cycling-endurance-challenge': {
    title: 'Cycling Endurance Challenge',
    description: 'Add 10 extra minutes to your cycling sessions each week.',
    startDate: '2024-07-01',
    endDate: '2024-07-31',
    image: Cycling,
    participants: [
      { name: 'Mia', status: 'Completed 3/4 weeks', progress: 75 },
      { name: 'Nathan', status: 'In Progress', progress: 50 },
      { name: 'Olivia', status: 'Completed 1/4 weeks', progress: 25 },
      { name: 'Paul', status: 'Not Started', progress: 0 },
      { name: 'Quincy', status: 'Completed 4/4 weeks', progress: 100 },
      { name: 'Rachel', status: 'In Progress', progress: 40 },
    ],
  },
  'swimming-stamina-challenge': {
    title: 'Swimming Stamina Challenge',
    description: 'Increase the number of laps by 2 each week.',
    startDate: '2024-07-01',
    endDate: '2024-07-31',
    image: Swimming,
    participants: [
      { name: 'Quinn', status: 'Completed 5/8 weeks', progress: 62.5 },
      { name: 'Rachel', status: 'In Progress', progress: 50 },
      { name: 'Sophie', status: 'Completed 2/8 weeks', progress: 25 },
      { name: 'Tom', status: 'Not Started', progress: 0 },
      { name: 'Uma', status: 'Completed 7/8 weeks', progress: 87.5 },
      { name: 'Victor', status: 'In Progress', progress: 30 },
    ],
  },
};

function App() {
  const location = useLocation();
  const [challenges, setChallenges] = useState(initialChallengeData);

  const handleJoinChallenge = (challengeId, participant) => {
    setChallenges(prevChallenges => {
      const updatedParticipants = [...prevChallenges[challengeId].participants, participant];
      return {
        ...prevChallenges,
        [challengeId]: {
          ...prevChallenges[challengeId],
          participants: updatedParticipants
        }
      };
    });
  };
  
  return (
    <div className="App">
      <Header>
        <h1>Fitness Website</h1>
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/signup">Sign Up</Link></li>
            <li><Link to="/AiCoach">AI Coach</Link></li>
            <li><Link to="/Chatbot">Chat</Link></li>
            <li><Link to="/Footer">Footer</Link></li>
          </ul>
        </nav>
      </Header>
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/workouts" element={<ProtectedRoute />}>
            <Route path="" element={<Workouts />} />
          </Route>
          <Route path="/nutrition" element={<ProtectedRoute />}>
            <Route path="" element={<Nutrition />} />
          </Route>
          <Route path="/AiCoach" element={<ProtectedRoute />}>
            <Route path="" element={<AiCoach />} />
          </Route>
          <Route path="/Chatbot" element={<ProtectedRoute />}>
            <Route path="" element={<Chatbot />} />
          </Route>
          <Route path="/challenge/:challengeId" element={<ProtectedRoute />}>
            <Route path="" element={<ChallengeDetails challenges={challenges} />} />
          </Route>
          <Route path="/join/:challengeId" element={<ProtectedRoute />}>
            <Route path="" element={<JoinChallenge challenges={challenges} onJoin={handleJoinChallenge} />} />
          </Route>
        </Routes>
        {location.pathname === '/' && <Footer />}
      </main>
    </div>
  );
}

export default function RootApp() {
  return (
    <Router>
      <App />
    </Router>
  );
}
