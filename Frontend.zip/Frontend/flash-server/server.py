from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai

app = Flask(__name__)
CORS(app)

API_KEY = 'AIzaSyCZBzi2InkYwj0Xk0k409bcB_x9BgSwZ8s'

genai.configure(api_key=API_KEY)

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(user_message)
    response_message = response.text
    # Assume the response is a string that contains multiple pieces of advice separated by newlines
    advice_list = response_message.split('\n')
    return jsonify({"response": advice_list})

if __name__ == '__main__':
    app.run(port=8080, debug=True)
